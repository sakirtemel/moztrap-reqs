from gunicorn.http.errors import InvalidHeader

request = InvalidHeader
